from mcpi.minecraft import Minecraft
import time
from mcpi import block

mc = Minecraft.create()
mc.postToChat("Any Message Here!!!!!!!")
